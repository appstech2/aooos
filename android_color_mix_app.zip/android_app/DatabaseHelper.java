package com.myapp.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    
    // معلومات قاعدة البيانات
    private static final String DATABASE_NAME = "app.db";
    private static final int DATABASE_VERSION = 1;
    
    // أسماء الجداول
    public static final String TABLE_USER = "user";
    public static final String TABLE_COLOR_MIXES = "color_mixes";
    public static final String TABLE_COLOR_COMPONENTS = "color_components";
    
    // أعمدة جدول المستخدمين
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_EMAIL = "email";
    
    // أعمدة جدول خلطات الألوان
    public static final String COLUMN_MIX_ID = "id";
    public static final String COLUMN_COLOR_CODE = "color_code";
    public static final String COLUMN_DESCRIPTION = "description";
    
    // أعمدة جدول مكونات الألوان
    public static final String COLUMN_COMPONENT_ID = "id";
    public static final String COLUMN_COLOR_MIX_ID = "color_mix_id";
    public static final String COLUMN_COLOR_NUMBER = "color_number";
    public static final String COLUMN_QUANTITY = "quantity";
    
    // استعلامات إنشاء الجداول
    private static final String CREATE_TABLE_USER = 
        "CREATE TABLE " + TABLE_USER + " (" +
        COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        COLUMN_USERNAME + " VARCHAR(80) NOT NULL UNIQUE, " +
        COLUMN_EMAIL + " VARCHAR(120) NOT NULL UNIQUE" +
        ")";
    
    private static final String CREATE_TABLE_COLOR_MIXES = 
        "CREATE TABLE " + TABLE_COLOR_MIXES + " (" +
        COLUMN_MIX_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        COLUMN_COLOR_CODE + " VARCHAR(50) NOT NULL, " +
        COLUMN_DESCRIPTION + " VARCHAR(200)" +
        ")";
    
    private static final String CREATE_TABLE_COLOR_COMPONENTS = 
        "CREATE TABLE " + TABLE_COLOR_COMPONENTS + " (" +
        COLUMN_COMPONENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        COLUMN_COLOR_MIX_ID + " INTEGER NOT NULL, " +
        COLUMN_COLOR_NUMBER + " VARCHAR(50) NOT NULL, " +
        COLUMN_QUANTITY + " REAL NOT NULL, " +
        "FOREIGN KEY(" + COLUMN_COLOR_MIX_ID + ") REFERENCES " + 
        TABLE_COLOR_MIXES + "(" + COLUMN_MIX_ID + ")" +
        ")";
    
    private static DatabaseHelper instance;
    
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    // الحصول على مثيل واحد من قاعدة البيانات (Singleton Pattern)
    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        // إنشاء الجداول
        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(CREATE_TABLE_COLOR_MIXES);
        db.execSQL(CREATE_TABLE_COLOR_COMPONENTS);
        
        // إدراج بيانات تجريبية
        insertSampleData(db);
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // حذف الجداول القديمة وإنشاء جداول جديدة
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COLOR_COMPONENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COLOR_MIXES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        onCreate(db);
    }
    
    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // تفعيل المفاتيح الخارجية
        db.execSQL("PRAGMA foreign_keys=ON");
    }
    
    // إدراج بيانات تجريبية
    private void insertSampleData(SQLiteDatabase db) {
        // إدراج خلطات الألوان
        db.execSQL("INSERT INTO " + TABLE_COLOR_MIXES + " (" + COLUMN_COLOR_CODE + ", " + COLUMN_DESCRIPTION + ") VALUES ('40', 'اتكلير')");
        db.execSQL("INSERT INTO " + TABLE_COLOR_MIXES + " (" + COLUMN_COLOR_CODE + ", " + COLUMN_DESCRIPTION + ") VALUES ('45', 'toyota')");
        db.execSQL("INSERT INTO " + TABLE_COLOR_MIXES + " (" + COLUMN_COLOR_CODE + ", " + COLUMN_DESCRIPTION + ") VALUES ('33', 'toyota')");
        db.execSQL("INSERT INTO " + TABLE_COLOR_MIXES + " (" + COLUMN_COLOR_CODE + ", " + COLUMN_DESCRIPTION + ") VALUES ('70=1', 'بطانه 070')");
        
        // إدراج مكونات الألوان
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (1, '10', 1342.5)");
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (1, '390', 2.5)");
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (1, '230', 4.9)");
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (1, '227', 1.2)");
        
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (2, '10', 1288.0)");
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (2, '390', 6.4)");
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (2, '225', 14.2)");
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (2, '230', 9.6)");
        db.execSQL("INSERT INTO " + TABLE_COLOR_COMPONENTS + " (" + COLUMN_COLOR_MIX_ID + ", " + COLUMN_COLOR_NUMBER + ", " + COLUMN_QUANTITY + ") VALUES (2, '650', 0.8)");
    }
}

