package com.myapp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.myapp.database.DatabaseHelper;
import com.myapp.models.ColorComponent;
import java.util.ArrayList;
import java.util.List;

public class ColorComponentDAO {
    private DatabaseHelper dbHelper;
    
    public ColorComponentDAO(Context context) {
        dbHelper = DatabaseHelper.getInstance(context);
    }
    
    // إدراج مكون لون جديد
    public long insertColorComponent(ColorComponent component) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(DatabaseHelper.COLUMN_COLOR_MIX_ID, component.getColorMixId());
        values.put(DatabaseHelper.COLUMN_COLOR_NUMBER, component.getColorNumber());
        values.put(DatabaseHelper.COLUMN_QUANTITY, component.getQuantity());
        
        long id = db.insert(DatabaseHelper.TABLE_COLOR_COMPONENTS, null, values);
        component.setId((int) id);
        
        return id;
    }
    
    // تحديث مكون لون
    public int updateColorComponent(ColorComponent component) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(DatabaseHelper.COLUMN_COLOR_MIX_ID, component.getColorMixId());
        values.put(DatabaseHelper.COLUMN_COLOR_NUMBER, component.getColorNumber());
        values.put(DatabaseHelper.COLUMN_QUANTITY, component.getQuantity());
        
        String whereClause = DatabaseHelper.COLUMN_COMPONENT_ID + " = ?";
        String[] whereArgs = {String.valueOf(component.getId())};
        
        return db.update(DatabaseHelper.TABLE_COLOR_COMPONENTS, values, whereClause, whereArgs);
    }
    
    // حذف مكون لون
    public int deleteColorComponent(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        String whereClause = DatabaseHelper.COLUMN_COMPONENT_ID + " = ?";
        String[] whereArgs = {String.valueOf(id)};
        
        return db.delete(DatabaseHelper.TABLE_COLOR_COMPONENTS, whereClause, whereArgs);
    }
    
    // حذف جميع مكونات خلطة لون معينة
    public int deleteComponentsByMixId(int mixId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        String whereClause = DatabaseHelper.COLUMN_COLOR_MIX_ID + " = ?";
        String[] whereArgs = {String.valueOf(mixId)};
        
        return db.delete(DatabaseHelper.TABLE_COLOR_COMPONENTS, whereClause, whereArgs);
    }
    
    // الحصول على مكون لون بالمعرف
    public ColorComponent getColorComponentById(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        ColorComponent component = null;
        
        String selection = DatabaseHelper.COLUMN_COMPONENT_ID + " = ?";
        String[] selectionArgs = {String.valueOf(id)};
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_COMPONENTS, null, 
                                selection, selectionArgs, null, null, null);
        
        if (cursor != null && cursor.moveToFirst()) {
            component = cursorToColorComponent(cursor);
            cursor.close();
        }
        
        return component;
    }
    
    // الحصول على مكونات خلطة لون معينة
    public List<ColorComponent> getComponentsByMixId(int mixId) {
        List<ColorComponent> components = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String selection = DatabaseHelper.COLUMN_COLOR_MIX_ID + " = ?";
        String[] selectionArgs = {String.valueOf(mixId)};
        String orderBy = DatabaseHelper.COLUMN_COLOR_NUMBER + " ASC";
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_COMPONENTS, null, 
                                selection, selectionArgs, null, null, orderBy);
        
        if (cursor != null) {
            // حساب إجمالي الكمية أولاً
            double totalQuantity = getTotalQuantityByMixId(mixId);
            
            while (cursor.moveToNext()) {
                ColorComponent component = cursorToColorComponent(cursor);
                // حساب النسبة المئوية
                component.calculatePercentage(totalQuantity);
                components.add(component);
            }
            cursor.close();
        }
        
        return components;
    }
    
    // الحصول على جميع مكونات الألوان
    public List<ColorComponent> getAllColorComponents() {
        List<ColorComponent> components = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String orderBy = DatabaseHelper.COLUMN_COLOR_MIX_ID + " ASC, " + 
                        DatabaseHelper.COLUMN_COLOR_NUMBER + " ASC";
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_COMPONENTS, null, 
                                null, null, null, null, orderBy);
        
        if (cursor != null) {
            while (cursor.moveToNext()) {
                ColorComponent component = cursorToColorComponent(cursor);
                components.add(component);
            }
            cursor.close();
        }
        
        return components;
    }
    
    // البحث في مكونات الألوان
    public List<ColorComponent> searchColorComponents(String query) {
        List<ColorComponent> components = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String selection = DatabaseHelper.COLUMN_COLOR_NUMBER + " LIKE ?";
        String[] selectionArgs = {"%" + query + "%"};
        String orderBy = DatabaseHelper.COLUMN_COLOR_MIX_ID + " ASC, " + 
                        DatabaseHelper.COLUMN_COLOR_NUMBER + " ASC";
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_COMPONENTS, null, 
                                selection, selectionArgs, null, null, orderBy);
        
        if (cursor != null) {
            while (cursor.moveToNext()) {
                ColorComponent component = cursorToColorComponent(cursor);
                components.add(component);
            }
            cursor.close();
        }
        
        return components;
    }
    
    // الحصول على إجمالي كمية مكونات خلطة لون معينة
    public double getTotalQuantityByMixId(int mixId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT SUM(" + DatabaseHelper.COLUMN_QUANTITY + ") FROM " + 
                      DatabaseHelper.TABLE_COLOR_COMPONENTS + " WHERE " + 
                      DatabaseHelper.COLUMN_COLOR_MIX_ID + " = ?";
        String[] selectionArgs = {String.valueOf(mixId)};
        
        Cursor cursor = db.rawQuery(query, selectionArgs);
        double totalQuantity = 0;
        
        if (cursor != null) {
            cursor.moveToFirst();
            totalQuantity = cursor.getDouble(0);
            cursor.close();
        }
        
        return totalQuantity;
    }
    
    // الحصول على عدد مكونات خلطة لون معينة
    public int getComponentsCountByMixId(int mixId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + DatabaseHelper.TABLE_COLOR_COMPONENTS + 
                      " WHERE " + DatabaseHelper.COLUMN_COLOR_MIX_ID + " = ?";
        String[] selectionArgs = {String.valueOf(mixId)};
        
        Cursor cursor = db.rawQuery(query, selectionArgs);
        int count = 0;
        
        if (cursor != null) {
            cursor.moveToFirst();
            count = cursor.getInt(0);
            cursor.close();
        }
        
        return count;
    }
    
    // التحقق من وجود رقم لون في خلطة معينة
    public boolean isColorNumberExists(int mixId, String colorNumber, int excludeId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String selection = DatabaseHelper.COLUMN_COLOR_MIX_ID + " = ? AND " +
                          DatabaseHelper.COLUMN_COLOR_NUMBER + " = ?";
        String[] selectionArgs = {String.valueOf(mixId), colorNumber};
        
        if (excludeId > 0) {
            selection += " AND " + DatabaseHelper.COLUMN_COMPONENT_ID + " != ?";
            selectionArgs = new String[]{String.valueOf(mixId), colorNumber, String.valueOf(excludeId)};
        }
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_COMPONENTS, null, 
                                selection, selectionArgs, null, null, null);
        
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) {
            cursor.close();
        }
        
        return exists;
    }
    
    // تحويل Cursor إلى ColorComponent
    private ColorComponent cursorToColorComponent(Cursor cursor) {
        ColorComponent component = new ColorComponent();
        
        component.setId(cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_COMPONENT_ID)));
        component.setColorMixId(cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_COLOR_MIX_ID)));
        component.setColorNumber(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_COLOR_NUMBER)));
        component.setQuantity(cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COLUMN_QUANTITY)));
        
        return component;
    }
}

