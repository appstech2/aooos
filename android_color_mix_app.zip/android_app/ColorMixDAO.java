package com.myapp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.myapp.database.DatabaseHelper;
import com.myapp.models.ColorMix;
import com.myapp.models.ColorComponent;
import java.util.ArrayList;
import java.util.List;

public class ColorMixDAO {
    private DatabaseHelper dbHelper;
    private ColorComponentDAO componentDAO;
    
    public ColorMixDAO(Context context) {
        dbHelper = DatabaseHelper.getInstance(context);
        componentDAO = new ColorComponentDAO(context);
    }
    
    // إدراج خلطة لون جديدة
    public long insertColorMix(ColorMix colorMix) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(DatabaseHelper.COLUMN_COLOR_CODE, colorMix.getColorCode());
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, colorMix.getDescription());
        
        long id = db.insert(DatabaseHelper.TABLE_COLOR_MIXES, null, values);
        colorMix.setId((int) id);
        
        return id;
    }
    
    // تحديث خلطة لون
    public int updateColorMix(ColorMix colorMix) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(DatabaseHelper.COLUMN_COLOR_CODE, colorMix.getColorCode());
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, colorMix.getDescription());
        
        String whereClause = DatabaseHelper.COLUMN_MIX_ID + " = ?";
        String[] whereArgs = {String.valueOf(colorMix.getId())};
        
        return db.update(DatabaseHelper.TABLE_COLOR_MIXES, values, whereClause, whereArgs);
    }
    
    // حذف خلطة لون
    public int deleteColorMix(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        // حذف المكونات أولاً
        componentDAO.deleteComponentsByMixId(id);
        
        // ثم حذف خلطة اللون
        String whereClause = DatabaseHelper.COLUMN_MIX_ID + " = ?";
        String[] whereArgs = {String.valueOf(id)};
        
        return db.delete(DatabaseHelper.TABLE_COLOR_MIXES, whereClause, whereArgs);
    }
    
    // الحصول على خلطة لون بالمعرف
    public ColorMix getColorMixById(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        ColorMix colorMix = null;
        
        String selection = DatabaseHelper.COLUMN_MIX_ID + " = ?";
        String[] selectionArgs = {String.valueOf(id)};
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_MIXES, null, 
                                selection, selectionArgs, null, null, null);
        
        if (cursor != null && cursor.moveToFirst()) {
            colorMix = cursorToColorMix(cursor);
            // تحميل المكونات
            List<ColorComponent> components = componentDAO.getComponentsByMixId(id);
            colorMix.setComponents(components);
            cursor.close();
        }
        
        return colorMix;
    }
    
    // الحصول على جميع خلطات الألوان
    public List<ColorMix> getAllColorMixes() {
        List<ColorMix> colorMixes = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String orderBy = DatabaseHelper.COLUMN_COLOR_CODE + " ASC";
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_MIXES, null, 
                                null, null, null, null, orderBy);
        
        if (cursor != null) {
            while (cursor.moveToNext()) {
                ColorMix colorMix = cursorToColorMix(cursor);
                // تحميل المكونات
                List<ColorComponent> components = componentDAO.getComponentsByMixId(colorMix.getId());
                colorMix.setComponents(components);
                colorMixes.add(colorMix);
            }
            cursor.close();
        }
        
        return colorMixes;
    }
    
    // البحث في خلطات الألوان
    public List<ColorMix> searchColorMixes(String query) {
        List<ColorMix> colorMixes = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String selection = DatabaseHelper.COLUMN_COLOR_CODE + " LIKE ? OR " +
                          DatabaseHelper.COLUMN_DESCRIPTION + " LIKE ?";
        String[] selectionArgs = {"%" + query + "%", "%" + query + "%"};
        String orderBy = DatabaseHelper.COLUMN_COLOR_CODE + " ASC";
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_MIXES, null, 
                                selection, selectionArgs, null, null, orderBy);
        
        if (cursor != null) {
            while (cursor.moveToNext()) {
                ColorMix colorMix = cursorToColorMix(cursor);
                // تحميل المكونات
                List<ColorComponent> components = componentDAO.getComponentsByMixId(colorMix.getId());
                colorMix.setComponents(components);
                colorMixes.add(colorMix);
            }
            cursor.close();
        }
        
        return colorMixes;
    }
    
    // الحصول على عدد خلطات الألوان
    public int getColorMixesCount() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + DatabaseHelper.TABLE_COLOR_MIXES;
        Cursor cursor = db.rawQuery(query, null);
        
        int count = 0;
        if (cursor != null) {
            cursor.moveToFirst();
            count = cursor.getInt(0);
            cursor.close();
        }
        
        return count;
    }
    
    // التحقق من وجود كود لون
    public boolean isColorCodeExists(String colorCode, int excludeId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String selection = DatabaseHelper.COLUMN_COLOR_CODE + " = ?";
        String[] selectionArgs = {colorCode};
        
        if (excludeId > 0) {
            selection += " AND " + DatabaseHelper.COLUMN_MIX_ID + " != ?";
            selectionArgs = new String[]{colorCode, String.valueOf(excludeId)};
        }
        
        Cursor cursor = db.query(DatabaseHelper.TABLE_COLOR_MIXES, null, 
                                selection, selectionArgs, null, null, null);
        
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) {
            cursor.close();
        }
        
        return exists;
    }
    
    // تحويل Cursor إلى ColorMix
    private ColorMix cursorToColorMix(Cursor cursor) {
        ColorMix colorMix = new ColorMix();
        
        colorMix.setId(cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_MIX_ID)));
        colorMix.setColorCode(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_COLOR_CODE)));
        colorMix.setDescription(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DESCRIPTION)));
        
        return colorMix;
    }
}

