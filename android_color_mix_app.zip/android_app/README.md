# تطبيق عرض قاعدة البيانات - Sketchware

## نظرة عامة
هذا التطبيق مصمم لعرض وإدارة قاعدة بيانات خلطات الألوان باستخدام Sketchware. يحتوي التطبيق على واجهات مستخدم حديثة وسهلة الاستخدام لعرض البيانات والتفاعل معها.

## هيكل قاعدة البيانات

### الجداول الموجودة:
1. **user** - جدول المستخدمين
   - id (INTEGER) - المعرف الفريد
   - username (VARCHAR) - اسم المستخدم
   - email (VARCHAR) - البريد الإلكتروني

2. **color_mixes** - جدول خلطات الألوان
   - id (INTEGER) - المعرف الفريد
   - color_code (VARCHAR) - كود اللون
   - description (VARCHAR) - وصف الخلطة

3. **color_components** - جدول مكونات الألوان
   - id (INTEGER) - المعرف الفريد
   - color_mix_id (INTEGER) - معرف خلطة اللون
   - color_number (VARCHAR) - رقم المكون
   - quantity (REAL) - الكمية

## ملفات XML المطلوبة

### الصفحات الرئيسية:
1. **activity_main.xml** - الصفحة الرئيسية
2. **activity_color_mixes.xml** - صفحة خلطات الألوان
3. **activity_color_components.xml** - صفحة مكونات الألوان
4. **activity_search.xml** - صفحة البحث
5. **activity_users.xml** - صفحة إدارة المستخدمين

### عناصر القوائم:
1. **item_color_mix.xml** - عنصر خلطة اللون في القائمة
2. **item_color_component.xml** - عنصر مكون اللون في القائمة
3. **item_user.xml** - عنصر المستخدم في القائمة

## ملفات Java المطلوبة

### النماذج (Models):
1. **User.java** - نموذج المستخدم
2. **ColorMix.java** - نموذج خلطة اللون
3. **ColorComponent.java** - نموذج مكون اللون

### قاعدة البيانات:
1. **DatabaseHelper.java** - مساعد قاعدة البيانات
2. **ColorMixDAO.java** - الوصول لبيانات خلطات الألوان
3. **ColorComponentDAO.java** - الوصول لبيانات مكونات الألوان

### المحولات (Adapters):
1. **ColorMixAdapter.java** - محول قائمة خلطات الألوان

### الأنشطة (Activities):
1. **MainActivity.java** - النشاط الرئيسي

## خطوات التطبيق في Sketchware

### 1. إنشاء المشروع:
- افتح Sketchware
- أنشئ مشروع جديد باسم "ColorMixDatabase"
- اختر الحزمة: com.myapp

### 2. إضافة الصفحات:
- أضف الأنشطة التالية:
  - MainActivity (موجود افتراضياً)
  - ColorMixesActivity
  - ColorComponentsActivity
  - SearchActivity
  - UsersActivity

### 3. تصميم الواجهات:
- انسخ محتوى ملفات XML إلى تصميم كل صفحة
- تأكد من إضافة جميع العناصر المطلوبة
- اضبط الخصائص والألوان حسب التصميم

### 4. إضافة الكود:
- انسخ كود Java إلى الأنشطة المناسبة
- أضف المكتبات المطلوبة
- تأكد من ربط العناصر بالكود

### 5. إعداد قاعدة البيانات:
- أضف ملف قاعدة البيانات إلى مجلد assets
- تأكد من تطبيق DatabaseHelper بشكل صحيح

## المكتبات المطلوبة

### في build.gradle (Module: app):
```gradle
dependencies {
    implementation 'androidx.recyclerview:recyclerview:1.2.1'
    implementation 'androidx.cardview:cardview:1.0.0'
    implementation 'com.google.android.material:material:1.4.0'
    implementation 'de.hdodenhof:circleimageview:3.1.0'
}
```

## الأيقونات المطلوبة

يجب إضافة الأيقونات التالية إلى مجلد drawable:
- ic_palette (أيقونة الألوان)
- ic_components (أيقونة المكونات)
- ic_search (أيقونة البحث)
- ic_users (أيقونة المستخدمين)
- ic_arrow_back (سهم الرجوع)
- ic_add (أيقونة الإضافة)
- ic_visibility (أيقونة العرض)
- ic_edit (أيقونة التعديل)
- ic_delete (أيقونة الحذف)
- ic_email (أيقونة البريد الإلكتروني)
- ic_person_add (أيقونة إضافة مستخدم)
- ic_no_data (أيقونة عدم وجود بيانات)
- ic_user_placeholder (صورة افتراضية للمستخدم)

## الخلفيات والأشكال المطلوبة

يجب إنشاء ملفات drawable التالية:
- search_background.xml (خلفية حقل البحث)
- button_outline.xml (خلفية الأزرار المحددة)
- edittext_background.xml (خلفية حقول النص)
- spinner_background.xml (خلفية القوائم المنسدلة)
- color_circle.xml (شكل دائرة اللون)
- component_number_background.xml (خلفية رقم المكون)
- count_background.xml (خلفية عداد النتائج)
- status_background.xml (خلفية حالة المستخدم)

## نصائح للتطبيق

1. **استخدم RecyclerView** لعرض القوائم بدلاً من ListView
2. **اضبط الخطوط** لتدعم النصوص العربية بشكل صحيح
3. **اختبر التطبيق** على أجهزة مختلفة للتأكد من التوافق
4. **أضف التحقق من الأخطاء** في جميع العمليات
5. **استخدم AsyncTask** للعمليات الطويلة لتجنب تجميد الواجهة

## الميزات المتاحة

- عرض جميع خلطات الألوان
- عرض مكونات كل خلطة
- البحث في البيانات
- إدارة المستخدمين
- واجهة مستخدم حديثة وسهلة الاستخدام
- دعم اللغة العربية

## المتطلبات

- Android API Level 21 أو أحدث
- Sketchware Pro (مستحسن)
- مساحة تخزين كافية لقاعدة البيانات

