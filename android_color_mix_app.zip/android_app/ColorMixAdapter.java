package com.myapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.myapp.models.ColorMix;
import java.util.List;

public class ColorMixAdapter extends RecyclerView.Adapter<ColorMixAdapter.ColorMixViewHolder> {
    
    private Context context;
    private List<ColorMix> colorMixes;
    private OnColorMixClickListener listener;
    
    // واجهة للتعامل مع النقرات
    public interface OnColorMixClickListener {
        void onViewDetailsClick(ColorMix colorMix);
        void onEditClick(ColorMix colorMix);
        void onDeleteClick(ColorMix colorMix);
        void onItemClick(ColorMix colorMix);
    }
    
    public ColorMixAdapter(Context context, List<ColorMix> colorMixes) {
        this.context = context;
        this.colorMixes = colorMixes;
    }
    
    public void setOnColorMixClickListener(OnColorMixClickListener listener) {
        this.listener = listener;
    }
    
    @NonNull
    @Override
    public ColorMixViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_color_mix, parent, false);
        return new ColorMixViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ColorMixViewHolder holder, int position) {
        ColorMix colorMix = colorMixes.get(position);
        holder.bind(colorMix);
    }
    
    @Override
    public int getItemCount() {
        return colorMixes.size();
    }
    
    // تحديث البيانات
    public void updateData(List<ColorMix> newColorMixes) {
        this.colorMixes = newColorMixes;
        notifyDataSetChanged();
    }
    
    // إضافة عنصر جديد
    public void addItem(ColorMix colorMix) {
        colorMixes.add(colorMix);
        notifyItemInserted(colorMixes.size() - 1);
    }
    
    // تحديث عنصر
    public void updateItem(int position, ColorMix colorMix) {
        if (position >= 0 && position < colorMixes.size()) {
            colorMixes.set(position, colorMix);
            notifyItemChanged(position);
        }
    }
    
    // حذف عنصر
    public void removeItem(int position) {
        if (position >= 0 && position < colorMixes.size()) {
            colorMixes.remove(position);
            notifyItemRemoved(position);
        }
    }
    
    // العثور على موضع عنصر بالمعرف
    public int findPositionById(int id) {
        for (int i = 0; i < colorMixes.size(); i++) {
            if (colorMixes.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }
    
    class ColorMixViewHolder extends RecyclerView.ViewHolder {
        private View colorPreview;
        private TextView tvColorCode;
        private TextView tvDescription;
        private TextView tvComponentsCount;
        private ImageButton btnViewDetails;
        private ImageButton btnEdit;
        private ImageButton btnDelete;
        
        public ColorMixViewHolder(@NonNull View itemView) {
            super(itemView);
            
            colorPreview = itemView.findViewById(R.id.color_preview);
            tvColorCode = itemView.findViewById(R.id.tv_color_code);
            tvDescription = itemView.findViewById(R.id.tv_description);
            tvComponentsCount = itemView.findViewById(R.id.tv_components_count);
            btnViewDetails = itemView.findViewById(R.id.btn_view_details);
            btnEdit = itemView.findViewById(R.id.btn_edit);
            btnDelete = itemView.findViewById(R.id.btn_delete);
            
            // إعداد المستمعين
            setupClickListeners();
        }
        
        public void bind(ColorMix colorMix) {
            // عرض كود اللون
            tvColorCode.setText(colorMix.getColorCode());
            
            // عرض الوصف
            String description = colorMix.getShortDescription();
            tvDescription.setText(description);
            
            // عرض عدد المكونات
            int componentsCount = colorMix.getComponentsCount();
            tvComponentsCount.setText("عدد المكونات: " + componentsCount);
            
            // تعيين لون المعاينة (لون تمثيلي بناءً على كود اللون)
            int color = generateColorFromCode(colorMix.getColorCode());
            colorPreview.setBackgroundColor(color);
        }
        
        private void setupClickListeners() {
            // النقر على العنصر بالكامل
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(colorMixes.get(position));
                    }
                }
            });
            
            // زر عرض التفاصيل
            btnViewDetails.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onViewDetailsClick(colorMixes.get(position));
                    }
                }
            });
            
            // زر التعديل
            btnEdit.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onEditClick(colorMixes.get(position));
                    }
                }
            });
            
            // زر الحذف
            btnDelete.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onDeleteClick(colorMixes.get(position));
                    }
                }
            });
        }
        
        // توليد لون تمثيلي من كود اللون
        private int generateColorFromCode(String colorCode) {
            try {
                // خوارزمية بسيطة لتوليد لون من النص
                int hash = colorCode.hashCode();
                int red = (hash & 0xFF0000) >> 16;
                int green = (hash & 0x00FF00) >> 8;
                int blue = hash & 0x0000FF;
                
                // تأكد من أن الألوان ليست داكنة جداً
                red = Math.max(red, 100);
                green = Math.max(green, 100);
                blue = Math.max(blue, 100);
                
                return android.graphics.Color.rgb(red, green, blue);
            } catch (Exception e) {
                // لون افتراضي في حالة الخطأ
                return android.graphics.Color.parseColor("#2196F3");
            }
        }
    }
}

