package com.myapp.models;

public class ColorComponent {
    private int id;
    private int colorMixId;
    private String colorNumber;
    private double quantity;
    private double percentage;
    
    // المنشئ الافتراضي
    public ColorComponent() {
    }
    
    // المنشئ مع المعاملات
    public ColorComponent(int id, int colorMixId, String colorNumber, double quantity) {
        this.id = id;
        this.colorMixId = colorMixId;
        this.colorNumber = colorNumber;
        this.quantity = quantity;
    }
    
    // المنشئ بدون ID (للإدراج الجديد)
    public ColorComponent(int colorMixId, String colorNumber, double quantity) {
        this.colorMixId = colorMixId;
        this.colorNumber = colorNumber;
        this.quantity = quantity;
    }
    
    // Getters
    public int getId() {
        return id;
    }
    
    public int getColorMixId() {
        return colorMixId;
    }
    
    public String getColorNumber() {
        return colorNumber;
    }
    
    public double getQuantity() {
        return quantity;
    }
    
    public double getPercentage() {
        return percentage;
    }
    
    // Setters
    public void setId(int id) {
        this.id = id;
    }
    
    public void setColorMixId(int colorMixId) {
        this.colorMixId = colorMixId;
    }
    
    public void setColorNumber(String colorNumber) {
        this.colorNumber = colorNumber;
    }
    
    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }
    
    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
    
    // حساب النسبة المئوية بناءً على إجمالي الكمية
    public void calculatePercentage(double totalQuantity) {
        if (totalQuantity > 0) {
            this.percentage = (quantity / totalQuantity) * 100;
        } else {
            this.percentage = 0;
        }
    }
    
    // تحويل إلى نص
    @Override
    public String toString() {
        return "ColorComponent{" +
                "id=" + id +
                ", colorMixId=" + colorMixId +
                ", colorNumber='" + colorNumber + '\'' +
                ", quantity=" + quantity +
                ", percentage=" + String.format("%.1f", percentage) + "%" +
                '}';
    }
    
    // التحقق من صحة البيانات
    public boolean isValid() {
        return colorNumber != null && !colorNumber.trim().isEmpty() && 
               quantity > 0 && colorMixId > 0;
    }
    
    // تنسيق الكمية مع الوحدة
    public String getFormattedQuantity() {
        if (quantity == (int) quantity) {
            return String.format("%.0f جم", quantity);
        } else {
            return String.format("%.1f جم", quantity);
        }
    }
    
    // تنسيق النسبة المئوية
    public String getFormattedPercentage() {
        return String.format("%.1f%%", percentage);
    }
    
    // الحصول على لون تمثيلي بناءً على رقم اللون
    public int getRepresentativeColor() {
        // تحويل رقم اللون إلى لون تمثيلي
        try {
            int colorNum = Integer.parseInt(colorNumber);
            // خوارزمية بسيطة لتوليد لون بناءً على الرقم
            int red = (colorNum * 7) % 256;
            int green = (colorNum * 13) % 256;
            int blue = (colorNum * 19) % 256;
            return android.graphics.Color.rgb(red, green, blue);
        } catch (NumberFormatException e) {
            // لون افتراضي في حالة عدم إمكانية تحويل الرقم
            return android.graphics.Color.GRAY;
        }
    }
}

