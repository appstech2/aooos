package com.myapp.models;

import java.util.ArrayList;
import java.util.List;

public class ColorMix {
    private int id;
    private String colorCode;
    private String description;
    private List<ColorComponent> components;
    private double totalQuantity;
    
    // المنشئ الافتراضي
    public ColorMix() {
        this.components = new ArrayList<>();
    }
    
    // المنشئ مع المعاملات
    public ColorMix(int id, String colorCode, String description) {
        this.id = id;
        this.colorCode = colorCode;
        this.description = description;
        this.components = new ArrayList<>();
    }
    
    // المنشئ بدون ID (للإدراج الجديد)
    public ColorMix(String colorCode, String description) {
        this.colorCode = colorCode;
        this.description = description;
        this.components = new ArrayList<>();
    }
    
    // Getters
    public int getId() {
        return id;
    }
    
    public String getColorCode() {
        return colorCode;
    }
    
    public String getDescription() {
        return description;
    }
    
    public List<ColorComponent> getComponents() {
        return components;
    }
    
    public double getTotalQuantity() {
        return totalQuantity;
    }
    
    // Setters
    public void setId(int id) {
        this.id = id;
    }
    
    public void setColorCode(String colorCode) {
        this.colorCode = colorCode;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public void setComponents(List<ColorComponent> components) {
        this.components = components;
        calculateTotalQuantity();
    }
    
    public void setTotalQuantity(double totalQuantity) {
        this.totalQuantity = totalQuantity;
    }
    
    // إضافة مكون
    public void addComponent(ColorComponent component) {
        this.components.add(component);
        calculateTotalQuantity();
    }
    
    // حذف مكون
    public void removeComponent(ColorComponent component) {
        this.components.remove(component);
        calculateTotalQuantity();
    }
    
    // حساب إجمالي الكمية
    public void calculateTotalQuantity() {
        totalQuantity = 0;
        for (ColorComponent component : components) {
            totalQuantity += component.getQuantity();
        }
    }
    
    // الحصول على عدد المكونات
    public int getComponentsCount() {
        return components.size();
    }
    
    // تحويل إلى نص
    @Override
    public String toString() {
        return "ColorMix{" +
                "id=" + id +
                ", colorCode='" + colorCode + '\'' +
                ", description='" + description + '\'' +
                ", componentsCount=" + getComponentsCount() +
                ", totalQuantity=" + totalQuantity +
                '}';
    }
    
    // التحقق من صحة البيانات
    public boolean isValid() {
        return colorCode != null && !colorCode.trim().isEmpty();
    }
    
    // الحصول على نص مختصر للوصف
    public String getShortDescription() {
        if (description == null || description.trim().isEmpty()) {
            return "بدون وصف";
        }
        if (description.length() > 50) {
            return description.substring(0, 47) + "...";
        }
        return description;
    }
}

