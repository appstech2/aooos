package com.myapp.models;

public class User {
    private int id;
    private String username;
    private String email;
    
    // المنشئ الافتراضي
    public User() {
    }
    
    // المنشئ مع المعاملات
    public User(int id, String username, String email) {
        this.id = id;
        this.username = username;
        this.email = email;
    }
    
    // المنشئ بدون ID (للإدراج الجديد)
    public User(String username, String email) {
        this.username = username;
        this.email = email;
    }
    
    // Getters
    public int getId() {
        return id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getEmail() {
        return email;
    }
    
    // Setters
    public void setId(int id) {
        this.id = id;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    // تحويل إلى نص
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
    
    // التحقق من صحة البيانات
    public boolean isValid() {
        return username != null && !username.trim().isEmpty() &&
               email != null && !email.trim().isEmpty() && 
               isValidEmail(email);
    }
    
    // التحقق من صحة البريد الإلكتروني
    private boolean isValidEmail(String email) {
        return email.contains("@") && email.contains(".");
    }
}

