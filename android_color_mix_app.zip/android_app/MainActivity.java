package com.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.myapp.database.DatabaseHelper;

public class MainActivity extends AppCompatActivity {
    
    private LinearLayout cardColorMixes;
    private LinearLayout cardColorComponents;
    private LinearLayout cardSearch;
    private LinearLayout cardUsers;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // تهيئة قاعدة البيانات
        initializeDatabase();
        
        // ربط العناصر
        initViews();
        
        // إعداد المستمعين
        setupClickListeners();
    }
    
    private void initializeDatabase() {
        // إنشاء مثيل من قاعدة البيانات لضمان إنشائها
        DatabaseHelper dbHelper = DatabaseHelper.getInstance(this);
        // فتح قاعدة البيانات للقراءة لتفعيل onCreate إذا لم تكن موجودة
        dbHelper.getReadableDatabase();
    }
    
    private void initViews() {
        cardColorMixes = findViewById(R.id.card_color_mixes);
        cardColorComponents = findViewById(R.id.card_color_components);
        cardSearch = findViewById(R.id.card_search);
        cardUsers = findViewById(R.id.card_users);
    }
    
    private void setupClickListeners() {
        // بطاقة خلطات الألوان
        cardColorMixes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ColorMixesActivity.class);
                startActivity(intent);
            }
        });
        
        // بطاقة مكونات الألوان
        cardColorComponents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // يمكن فتح صفحة عرض جميع المكونات أو اختيار خلطة أولاً
                Intent intent = new Intent(MainActivity.this, ColorMixesActivity.class);
                intent.putExtra("show_components", true);
                startActivity(intent);
            }
        });
        
        // بطاقة البحث
        cardSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });
        
        // بطاقة المستخدمين
        cardUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, UsersActivity.class);
                startActivity(intent);
            }
        });
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // يمكن تحديث الإحصائيات هنا إذا لزم الأمر
        updateStatistics();
    }
    
    private void updateStatistics() {
        // يمكن إضافة عرض إحصائيات سريعة على الصفحة الرئيسية
        // مثل عدد خلطات الألوان، عدد المكونات، إلخ
    }
}

